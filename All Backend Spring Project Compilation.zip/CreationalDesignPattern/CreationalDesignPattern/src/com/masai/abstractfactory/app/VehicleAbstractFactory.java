package com.masai.abstractfactory.app;

public interface VehicleAbstractFactory {
	
	public Vehicle createVehicle();
}
