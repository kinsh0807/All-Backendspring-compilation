package com.masai.webapp.example.service;

import java.util.List;

import com.masai.webapp.example.entity.Student;

public interface StudentService {

	public List<Student> addStudent(Student student);
	public boolean deleteStudent(int stuId);
	public List<Student> getStudents();
	public Student getStudent(int stuId);
	
}
