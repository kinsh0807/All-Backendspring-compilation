package com.masai.webapp.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.masai.webapp.example.entity.Student;
import com.masai.webapp.example.exceptions.InvalidMarksException;
import com.masai.webapp.example.service.StudentService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("api_v2")
public class MyControllerV2 {
	
	@Autowired
	StudentService service;
	
	@PostMapping("/students")
	public ResponseEntity<?> createStudent(@Valid @RequestBody Student student) {
		
		if(student.getMarks() >= 500) {
			throw new InvalidMarksException("Please enter valid marks..!");
		
		}else {
			List<Student> studentList = service.addStudent(student);
			return new ResponseEntity<List<Student>>(studentList, HttpStatus.CREATED);
		}
	}
	
	/*@ExceptionHandler(IllegalArgumentException.class)
	public ResponseEntity<String> myExceptionHandler(IllegalArgumentException ex) {
		System.out.println("In My Exception Handler Method...");
		return new ResponseEntity<String>(ex.getMessage(),HttpStatus.BAD_REQUEST);
	}*/
	
	

}
