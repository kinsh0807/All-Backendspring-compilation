package com.masai.firapp.entity;




@Entity



public class User {
     private String firstName;
     private String  lastName;
     private String mobileNumber;
     private String address;
     private int age;
     private String gender;
     private String password;
}
