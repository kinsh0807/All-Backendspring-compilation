package com.masai.command;

public interface Command {

	public void execute();
}
