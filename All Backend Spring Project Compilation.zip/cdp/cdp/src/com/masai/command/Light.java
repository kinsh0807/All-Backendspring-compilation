package com.masai.command;

public class Light {

	public void on() {
	}
	public void off() {
	}
}
