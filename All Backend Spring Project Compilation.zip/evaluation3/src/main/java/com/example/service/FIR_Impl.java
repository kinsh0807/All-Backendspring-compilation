package com.example.service;

import com.example.entity.FIR;
import com.example.repository.FIR_Repo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
    public class FIR_Impl implements Service_FIR{

        @Autowired
        FIR_Repo firRepo;

        @Override
        public FIR createFir(FIR fir) {
            return firRepo.save(fir);
        }
    }

