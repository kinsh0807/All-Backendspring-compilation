package com.example.service;

import com.example.entity.User;
import com.example.repository.User_Repo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class User_Impl implements Service_User{

    @Autowired
    User_Repo userRepo;

    @Override
    public User createUser(User user) {
        return userRepo.save(user);
    }

    @Override
    public User getUserbyId(int u_id) {
            return userRepo.findById(u_id).get();

    }
}
