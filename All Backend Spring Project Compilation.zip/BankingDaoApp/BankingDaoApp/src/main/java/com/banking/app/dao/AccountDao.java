package com.banking.app.dao;

import java.util.List;

import com.banking.app.entity.Account;

public interface AccountDao {

	public boolean createAccount(Account account);
	
	public boolean deleteAccount(int accno);
	
	public boolean updateAccount(Account account);
	
	public Account findAccountById(int accno);
	
	public Account findAccountByName(String name);
	
	public List<Account> findAll();
}
