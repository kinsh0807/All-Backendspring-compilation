package com.masai.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Evaluation2q2Application {

	public static void main(String[] args) {
		SpringApplication.run(Evaluation2q2Application.class, args);
		
		System.out.println("The application has started running");
	} 

}
