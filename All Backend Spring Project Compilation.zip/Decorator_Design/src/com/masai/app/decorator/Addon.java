package com.masai.app.decorator;

abstract class Addon extends Beverage{
    public abstract String getDescription();


}
