package com.masai.app.decorator;

public class Test {

     public static void main(String[] args) {
         HouseBlend houseblend = new HouseBlend();
         DarkRoast darkRoast = new DarkRoast();

         houseblend.cost();
         houseblend.getDescription();
         darkRoast.cost();
         darkRoast.getDescription();
     }
}
