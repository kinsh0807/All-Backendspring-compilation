package com.masai.app.decorator;

public class Sugar extends Addon {

    private Beverage beverage;

    Sugar(Beverage beverage) {
        this.beverage = beverage;
    }

    public String getDescription() {
        return beverage.getDescription() + ", Sugar";
    }

    @Override
    public double cost() {
        return beverage.cost() + 1.5D;
    }
}
