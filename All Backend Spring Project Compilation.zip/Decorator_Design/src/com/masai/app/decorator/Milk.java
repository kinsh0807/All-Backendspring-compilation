package com.masai.app.decorator;

public class Milk extends Addon{

    private Beverage beverage;

    Milk(Beverage beverage) {
        this.beverage = beverage;
    }

    public String getDescription() {
        return beverage.getDescription() + ", Milk";
    }

    @Override
    public double cost() {
        return beverage.cost();
    }
}
