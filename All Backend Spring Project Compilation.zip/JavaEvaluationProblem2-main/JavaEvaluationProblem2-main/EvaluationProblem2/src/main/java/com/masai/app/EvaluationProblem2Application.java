package com.masai.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EvaluationProblem2Application {

	public static void main(String[] args) {
		SpringApplication.run(EvaluationProblem2Application.class, args);
	}

}
