package com.masai.app;

import org.springframework.boot.SpringApplication;

public class App {

	public static void main(String[] args) {
		SpringApplication.run(App.class, args);
		System.out.println("Application has started running");
	}

}
