package com.employee.app;

import java.util.List;


import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.employee.app.dao.CarDao;
import com.employee.app.dao.CarDaoImpl;
import com.employee.app.dao.EmployeeDao;
import com.employee.app.dao.EmployeeDaoInter;
import com.employee.app.entity.Car;
import com.employee.app.entity.Employee;
import com.employee.app.util.EmuUtils;


public class App {

	public static void main(String[] args) {
//		CarDao ca=new CarDaoImpl();
//		List<Car> cars=ca.findall();
//		cars.stream().forEach(System.out::println);
//		EmployeeDaoInter es=new EmployeeDao();
//		List<Employee> employees=es.findalle();
//		employees.stream().forEach(System.out::println);
		
		EntityManager em=EmuUtils.EntityManagerprovider();
		String cmd ="Update Employee set salary=salary+:sal";
		Query query = em.createQuery(cmd);
		query.setParameter("sal", 2000);
		
		em.getTransaction().begin();
		int rows = query.executeUpdate();
		em.getTransaction().commit();
		
		System.out.println("no. of rows updated="+rows);
		
		em.close();
		
		
		
	}

}
