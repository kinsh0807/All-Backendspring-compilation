package com.employee.app.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.employee.app.entity.Car;
import com.employee.app.entity.Employee;
import com.employee.app.util.EmuUtils;

public class EmployeeDao implements EmployeeDaoInter {

	@Override
	public boolean AddEmployee(Employee employee) {
		EntityManager em=EmuUtils.EntityManagerprovider();
		boolean EmployeeAdded=false;
		em.getTransaction().begin();
		em.persist(employee);
		em.getTransaction().commit();
		EmployeeAdded=true;
		em.close();
		return EmployeeAdded;
	}

	@Override
	public boolean DeleteEmployee(int Emp_id) {
		EntityManager em=EmuUtils.EntityManagerprovider();
		boolean EmployeeDeleted=false;
		Employee employee = em.find(Employee.class, Emp_id);
		em.getTransaction().begin();

		em.remove(employee);
		em.getTransaction().commit();
		EmployeeDeleted=true;
		em.close();
		return EmployeeDeleted;
	}

	@Override
	public boolean UpdateEmployee(Employee employee) {
		
		EntityManager em=EmuUtils.EntityManagerprovider();
		boolean EmployeeUpdated=false;
		//Employee=employee=em.find(Employee.class, Emp_id);
		em.getTransaction().begin();
		em.merge(employee);
		em.getTransaction().commit();
		EmployeeUpdated=true;
		em.close();
		
		
		return EmployeeUpdated;
	}

	@Override
	public Employee FindEmployee(int Emp_id) {
		// TODO Auto-generated method stub
		
		return EmuUtils.EntityManagerprovider().find(Employee.class, Emp_id);
	}


	@Override
	public List<Employee> findalle() {
		EntityManager em=EmuUtils.EntityManagerprovider();
		String jp="from Employee";
		Query query= em.createQuery(jp);
		List<Employee> ls = query.getResultList();
		return ls;
	}

}
