package com.employee.app.dao;

import java.util.List;

import com.employee.app.entity.Car;


//import com.employee.app.entity.Employee;

public interface CarDao {
	
	public boolean AddCar(Car car);
	public boolean DeleteCar(int id);
	public Car UpdateCar(int id);
	public Car findCar(int id);
	public List<Car> findall();

}
