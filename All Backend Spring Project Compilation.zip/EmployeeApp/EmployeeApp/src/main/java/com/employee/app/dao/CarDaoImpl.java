package com.employee.app.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.employee.app.entity.Car;
import com.employee.app.util.EmuUtils;

public class CarDaoImpl implements CarDao{

	@Override
	public boolean AddCar(Car car) {
		EntityManager em=EmuUtils.EntityManagerprovider();
		boolean CarAdded=false;
		em.getTransaction().begin();
		em.persist(car);
		em.getTransaction().commit();
		CarAdded=true;
		em.close();
		return CarAdded;
	}

	@Override
	public boolean DeleteCar(int id) {
		EntityManager em=EmuUtils.EntityManagerprovider();
		boolean CarDeleted=false;
		Car car =em.find(Car.class, id);
		if(car!=null) {
		em.getTransaction().begin();
		em.remove(car);
		em.getTransaction().commit();
		CarDeleted=true;
		em.close();
		}else {
			System.out.println("No car");
		}
		return CarDeleted;
	}

	@Override
	public Car UpdateCar(int id) {
		EntityManager em=EmuUtils.EntityManagerprovider();
		Car car =em.find(Car.class, id);
		em.getTransaction().begin();
		em.merge(car);
		em.getTransaction().commit();
		em.close();
		return car;
	}

	@Override
	public Car findCar(int id) {
		// TODO Auto-generated method stub
		return EmuUtils.EntityManagerprovider().find(Car.class, id);
	}

	@Override
	public List<Car> findall() {
		EntityManager em=EmuUtils.EntityManagerprovider();
		String jpg="from Car";
		Query query= em.createQuery(jpg);
		List<Car> ls = query.getResultList();
		return ls;
	}
	
	
	
	

}
