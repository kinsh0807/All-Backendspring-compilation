package com.employee.app.entity;

import java.util.Objects;

import javax.persistence.Entity;
import javax.persistence.GenerationType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Employee {
	@Id
	//@GeneratedValue(strategy=GenerationType.AUTO)
	private int Emp_id;
	
	private String name;
	private int salary;
	private String branch;
	private String DOB;
	
	public  Employee() {}

	public Employee(int emp_id, String name, int salary, String branch, String dOB) {
		super();
		Emp_id = emp_id;
		this.name = name;
		this.salary = salary;
		this.branch = branch;
		DOB = dOB;
	}

	public int getEmp_id() {
		return Emp_id;
	}

	public void setEmp_id(int emp_id) {
		Emp_id = emp_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getDOB() {
		return DOB;
	}

	public void setDOB(String dOB) {
		DOB = dOB;
	}

	@Override
	public String toString() {
		return "Employee [Emp_id=" + Emp_id + ", name=" + name + ", salary=" + salary + ", branch=" + branch + ", DOB="
				+ DOB + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(DOB, Emp_id, branch, name, salary);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		return Objects.equals(DOB, other.DOB) && Emp_id == other.Emp_id && Objects.equals(branch, other.branch)
				&& Objects.equals(name, other.name) && salary == other.salary;
	}
	
	
	
	
	

}
