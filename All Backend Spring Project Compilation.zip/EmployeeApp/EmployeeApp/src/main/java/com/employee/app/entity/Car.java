package com.employee.app.entity;

import java.util.Objects;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Car {
	
	@Id
	 private int id;
	 
	 
	 private String modelName;
	 private int year;
	 private String color;
	 
	 public Car() {}
	 
	public Car(int id, String modelName, int year, String color) {
		super();
		this.id = id;
		this.modelName = modelName;
		this.year = year;
		this.color = color;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getModelName() {
		return modelName;
	}
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	@Override
	public String toString() {
		return "Car [id=" + id + ", modelName=" + modelName + ", year=" + year + ", color=" + color + "]";
	}
	@Override
	public int hashCode() {
		return Objects.hash(color, id, modelName, year);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Car other = (Car) obj;
		return Objects.equals(color, other.color) && id == other.id && Objects.equals(modelName, other.modelName)
				&& year == other.year;
	}
	 
	 
}
