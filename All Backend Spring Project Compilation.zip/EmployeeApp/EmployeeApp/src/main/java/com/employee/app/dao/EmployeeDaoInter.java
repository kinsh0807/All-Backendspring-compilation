package com.employee.app.dao;

import java.util.List;

import com.employee.app.entity.Employee;

public interface EmployeeDaoInter {
	public boolean AddEmployee(Employee employee);
	
	public boolean DeleteEmployee(int Emp_Id);
	
	public boolean UpdateEmployee(Employee employee);
	public Employee FindEmployee(int Emp_id);
	public List<Employee> findalle();
	

}
