package com.masai.webapp.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.masai.webapp.example.entity.Post;
import com.masai.webapp.example.repository.Post_Repo;

@Service
public class PostServiceImpl implements Post_Service {

	@Autowired
	private Post_Repo repository;

	@Override
	public List<Post> createPost(Post post) {
		Post pt =this.repository.save(post);
		return this.repository.findAll();
	}





}
