package com.masai.webapp.example.service;

import com.masai.webapp.example.entity.Post;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface Post_Service {


    public List<Post> createPost(Post post);


}
