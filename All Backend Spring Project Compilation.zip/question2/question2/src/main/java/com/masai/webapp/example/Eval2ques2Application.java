package com.masai.webapp.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Eval2ques2Application {

	public static void main(String[] args) {
		SpringApplication.run(Eval2ques2Application.class, args);
	}

}
