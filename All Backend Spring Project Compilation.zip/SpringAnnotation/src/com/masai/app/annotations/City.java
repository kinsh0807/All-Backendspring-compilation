package com.masai.app.annotations;

import java.util.List;

public class City {
	
	
	private List <String> cities;
	
	public City () {}
	
	
	public City(List<String> cities) {
		super();
		this.cities = cities;
	}


	public List<String> getCities() {
		return cities;
	}


	public void setCities(List<String> cities) {
		this.cities = cities;
	}


	@Override
	public String toString() {
		return "City [cities=" + cities + "]";
	}


	public void cityDetails() {
		System.out.println("City name is" +cities);
	}
	

}
