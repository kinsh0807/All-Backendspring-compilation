package com.masai.creational_pattern.adapter;

public class AdapterTest {

	public static void main(String[] args) {
		//SocketAdapter socketAdapter = new SocketClassAdapterImpl();
		SocketAdapter socketAdapter = new SocketObjectAdapterImpl();
		//Volt v3 = socketAdapter.get3Volt();
		
		Volt v3 = getVolt(socketAdapter, 3);
		Volt v12 = getVolt(socketAdapter, 12);
		System.out.println("volts generated from adapter:  "+v3.getVolts());
		//System.out.println("volts generated from adapter: "+v12.getVolts());
	}

	
	private static Volt getVolt(SocketAdapter socketAdapter, int i) {
		switch (i) {
		case 3:
			return socketAdapter.get3Volt();
		case 12:
			return socketAdapter.get12Volt();
		case 120:
			return socketAdapter.get120Volt();
		default:
			return socketAdapter.get120Volt();
		}
	}
}
