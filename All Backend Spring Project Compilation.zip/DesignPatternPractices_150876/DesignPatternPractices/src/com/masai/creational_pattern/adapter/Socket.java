package com.masai.creational_pattern.adapter;

public class Socket {

	public Volt getVolts() {
		return new Volt(120);
	}
	
	public void hello() {
		System.out.println("New method introduced in socket");
	}
}
