package com.masai.creational_pattern.bridge;

public class RedColor implements Color{

	@Override
	public void applyColor() {
		System.out.println("Red color applied..!");
	}

}
