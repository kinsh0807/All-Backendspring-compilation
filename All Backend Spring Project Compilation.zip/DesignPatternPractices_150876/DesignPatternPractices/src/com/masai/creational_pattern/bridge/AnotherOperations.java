package com.masai.creational_pattern.bridge;

public interface AnotherOperations {

	public void feature1();
}
