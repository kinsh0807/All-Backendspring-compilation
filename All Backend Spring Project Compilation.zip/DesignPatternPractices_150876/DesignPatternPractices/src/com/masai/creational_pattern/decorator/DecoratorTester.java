package com.masai.creational_pattern.decorator;

public class DecoratorTester {

	public static void main(String[] args) {

		Car carr = new SportsCar(new BasicCar());
		carr.assemble();
		System.out.println("================");
		Car carrr = new SportsCar(new LuxuryCar(new BasicCar()));
		carrr.assemble();
		System.out.println("================");
		Car luxuryCar = new LuxuryCar(new SportsCar(new BasicCar()));
		luxuryCar.assemble();
		System.out.println("================");
		Car basic = new BasicCar();
		basic.assemble();
	}

}
