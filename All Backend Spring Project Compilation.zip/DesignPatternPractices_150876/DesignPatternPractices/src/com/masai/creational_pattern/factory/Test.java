package com.masai.creational_pattern.factory;

public class Test {

	public static void main(String[] args) {
		
		Computer computer = ComputerFactory.getComputer("pc", "16 GB", "1 TB", "3.0 Ghz");
		
		System.out.println(computer);

		if(computer instanceof PC)
			System.out.println("Its a personal computer");
		else if(computer instanceof Server)
			System.out.println("Its a server computer");
	}

}
