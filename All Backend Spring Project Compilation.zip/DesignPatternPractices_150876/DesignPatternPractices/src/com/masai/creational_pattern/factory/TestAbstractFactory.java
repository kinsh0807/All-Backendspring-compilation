package com.masai.creational_pattern.factory;

public class TestAbstractFactory {

	public static void main(String[] args) {

		//Abstract Factory object
		PCFactory factory = new PCFactory("4 GB", "512 GB", "2.5 GHz");
		
		ServerFactory factory2 = new ServerFactory("32 GB", "2 TB", "3.0 GHz Intel i9");
		
		Computer computer = ComputerFactoryV2.getComputer(factory2);
		
		if(computer instanceof PC) {
			System.out.println(computer);
			System.out.println("Its a personal computer");
		}else if(computer instanceof Server) {
			System.out.println(computer);
			System.out.println("Its a Server computer");
		}
	}

}
