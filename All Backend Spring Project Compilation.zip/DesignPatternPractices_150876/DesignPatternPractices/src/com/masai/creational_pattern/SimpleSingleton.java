package com.masai.creational_pattern;

public class SimpleSingleton {

	//Eagerly creating the instance at time of class loading
	//private static final SimpleSingleton instance = new SimpleSingleton();
	
	private static SimpleSingleton instance;
	
	static {
		try {
			instance = new SimpleSingleton();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	private SimpleSingleton() {}
	
	public static SimpleSingleton getInstance() {
		return instance;
	}
	
}
