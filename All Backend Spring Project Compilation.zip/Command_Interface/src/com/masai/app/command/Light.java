package com.masai.app.command;

public class Light {

    public void on() {

    }

    public void off() {

    }
}
