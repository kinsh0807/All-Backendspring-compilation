package com.masai.app.command;

public interface Command {

        public void execute();

}
