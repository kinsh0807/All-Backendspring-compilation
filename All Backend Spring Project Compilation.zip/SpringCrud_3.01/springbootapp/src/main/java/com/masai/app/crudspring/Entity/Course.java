package com.masai.app.crudspring.Entity;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToOne;

@Entity
public class Course {

	@Id
	private int course_Id;
	private String name;
	@OneToOne
	private Syllabus syllabus;
	@ManyToMany
	private List<Student> students;

	public Course() {
	}

	public Course(int cId, String cname, Syllabus syllabus, List<Student> students) {
		super();
		this.course_Id = course_Id;
		this.name = name;
		this.syllabus = syllabus;
		this.students = students;
	}

	public int getcourse_Id() {
		return course_Id;
	}

	public void course_Id(int course_Id) {
		this.course_Id = course_Id;
	}

	public String getCname() {
		return name;
	}

	public void setCname(String cname) {
		this.name = name;
	}

	public Syllabus getSyllabus() {
		return syllabus;
	}

	public void setSyllabus(Syllabus syllabus) {
		this.syllabus = syllabus;
	}

	public List<Student> getStudents() {
		return students;
	}

	public void setStudents(List<Student> students) {
		this.students = students;
	}

}
