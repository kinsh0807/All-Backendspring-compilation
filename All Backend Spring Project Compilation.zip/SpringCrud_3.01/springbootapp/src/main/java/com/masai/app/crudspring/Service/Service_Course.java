package com.masai.app.crudspring.Service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.masai.app.crudspring.Entity.Course;
import com.masai.app.crudspring.Entity.Syllabus;

@Service
public interface Service_Course {

	List<Course> getAllCourses();

	Course getCourseById(int id);

	Course createCourse(Course course);

	Course updateCourse(Course course);

	Syllabus getCourseSyllabus(int id);

	Syllabus createCourseSyllabus(Syllabus syllabus);
}
