package com.masai.app.crudspring.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.masai.app.crudspring.Entity.Course;
import com.masai.app.crudspring.Entity.Syllabus;
import com.masai.app.crudspring.Reposit.CourseRepository;
import com.masai.app.crudspring.Reposit.SyllabusRepository;

@Service
public class ServiceCourseImpl implements Service_Course {

	@Autowired
	CourseRepository courserepository;
	@Autowired
	SyllabusRepository syrepository;


	@Override
	public List<Course> getAllCourses() {
		return courserepository.findAll();
	}

	@Override
	public Course getCourseById(int id) {
		return courserepository.findById(id).get();
	}

	@Override
	public Course createCourse(Course course) {
		return courserepository.save(course);
	}

	@Override
	public Course updateCourse(Course course) {
		return courserepository.save(course);
	}

	@Override
	public Syllabus getCourseSyllabus(int id) {
		return courserepository.findById(id).get().getSyllabus();
	}

	@Override
	public Syllabus createCourseSyllabus(Syllabus syllabus) {
		return syrepository.save(syllabus);
	}

}
