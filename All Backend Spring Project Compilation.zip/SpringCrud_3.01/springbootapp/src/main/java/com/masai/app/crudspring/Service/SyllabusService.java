package com.masai.app.crudspring.Service;


import com.masai.app.crudspring.Entity.Syllabus;

public interface SyllabusService {

	public Syllabus getSyllabus(int id);
	public Syllabus createSyllabus(Syllabus syllabus);
}
