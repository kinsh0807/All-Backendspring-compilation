package com.masai.creational_pattern.behavioral.command;

public class Order implements Command{

	private Cheff cheff;
	private String food;
	
	public Order(Cheff cheff, String food) {
		this.cheff = cheff;
		this.food = food;
	}
	
	@Override
	public void execute() {
		if(this.food.equalsIgnoreCase("fries")) {
			this.cheff.cookFries();
		}else if(this.food.equalsIgnoreCase("pasta")){
			this.cheff.cookPaste();
		}else {
			this.cheff.bake();
		}
	}

	
}
