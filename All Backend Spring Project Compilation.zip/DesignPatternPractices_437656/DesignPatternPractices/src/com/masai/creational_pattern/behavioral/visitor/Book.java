package com.masai.creational_pattern.behavioral.visitor;

public class Book implements Item {

	private int price;
	private String isbnNumber;
	
	public Book(int cost, String isbn) {
		this.price = cost;
		this.isbnNumber = isbn;
	}
	
	public int getPrice() {
		return this.price;
	}
	
	public String getIsbnNumber() {
		return this.isbnNumber;
	}
	
	@Override
	public int accept(ShopingCartVisitor visitor) {
		// TODO Auto-generated method stub
		return visitor.visit(this);
	}

}
