package com.masai.creational_pattern.behavioral.chainpattern;

public class Rupee20Dispenser implements DispenseChain{
	
	private DispenseChain chain;

	@Override
	public void setNextChain(DispenseChain nextChain) {
		this.chain = nextChain;
	}

	@Override
	public void dispense(Currency currency) {
		
		if(currency.getAmount() >= 20) {
			int num = currency.getAmount()/20;
			int rem = currency.getAmount() % 20;
			System.out.println("Dispensing "+num+" of 20 rupee notes..!");
			if(rem != 0) this.chain.dispense(new Currency(rem));
		}else {
			this.chain.dispense(currency);
		}
		
	}
	
	

}
