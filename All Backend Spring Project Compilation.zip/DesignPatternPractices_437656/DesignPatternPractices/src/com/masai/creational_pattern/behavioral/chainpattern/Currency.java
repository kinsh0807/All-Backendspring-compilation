package com.masai.creational_pattern.behavioral.chainpattern;

public class Currency {

	private int amount;
	
	public Currency(int amount) {
		this.amount = amount;
	}
	
	public int getAmount() {
		return amount;
	}
}
