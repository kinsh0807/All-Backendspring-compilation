package com.masai.creational_pattern.behavioral.command;

public class Client {

	public static void main(String[] args) {
		
		Cheff cheff = new Cheff();
		
		Order order = new Order(cheff, "pasta");
		
		Waiter waiter = new Waiter(order);
		
		waiter.execute();
		
		Order order2 = new Order(cheff, "fries");
		
		waiter = new Waiter(order2);
		
		waiter.execute();
	}

}
