package com.masai.creational_pattern.behavioral.chainpattern;

import java.util.Scanner;

public class ATMDispenserTest {

	private DispenseChain chain1;

	public ATMDispenserTest() {
		//Create all dispenser objects
		chain1 = new Rupee50Dispenser();
		DispenseChain chain2 = new Rupee20Dispenser();
		DispenseChain chain3 = new Rupee10Dispenser();
		
		//set their chain
		chain1.setNextChain(chain2);
		chain2.setNextChain(chain3);
	}
	
	public static void main(String[] args) {	
		Scanner sc = new Scanner(System.in);
		ATMDispenserTest atmDispenser = new ATMDispenserTest();
		
		int amount = 0;
		
		System.out.println("Enter the amount :");
		amount = sc.nextInt();
		
		if(amount % 10 != 0) {
			System.out.println("Amount should be multiple of 10..!");
			System.exit(1);
		}else {
			atmDispenser.chain1.dispense(new Currency(amount));
		}
		
		sc.close();

	}

}
