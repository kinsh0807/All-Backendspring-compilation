package com.masai.creational_pattern.behavioral.visitor;

public class VisitorTest {

	public static void main(String[] args) {
		Item item = new Book(150, "ISBN1234");
		int price = calculatePrice(item);
		System.out.println(price);
	}

	public static int calculatePrice(Item item) {
		ShopingCartVisitor visitor = new ShopingCartVisitorImpl();
		int price = item.accept(visitor);
		return price;
	}
}
