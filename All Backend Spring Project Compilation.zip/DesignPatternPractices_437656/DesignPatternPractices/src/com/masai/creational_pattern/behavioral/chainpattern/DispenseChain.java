package com.masai.creational_pattern.behavioral.chainpattern;

public interface DispenseChain {

	public void setNextChain(DispenseChain nextChain);
	public void dispense(Currency currency);
	
}
