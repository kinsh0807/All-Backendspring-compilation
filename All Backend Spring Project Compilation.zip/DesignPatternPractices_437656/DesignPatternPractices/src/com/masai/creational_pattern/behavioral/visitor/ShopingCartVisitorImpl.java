package com.masai.creational_pattern.behavioral.visitor;

public class ShopingCartVisitorImpl implements ShopingCartVisitor{

	/*
	@Override
	public int visit(Book book) {
		int cost = 0;
		//if book price is more than 100 ruppe - give 5% discount
		if(book.getPrice()>100) {
			cost = book.getPrice()-5;
		}else {
			cost = book.getPrice();
		}
		System.out.println("Book "+book.getIsbnNumber() + " cost "+cost);
		
		return cost;
	}

	@Override
	public int visit(Fruit fruit) {
		int cost = fruit.getPricePerKg()*fruit.getWeight();
		System.out.println(fruit.getName()+" cost :"+cost);
		return cost;
	}*/

	public int visit(Item item) {
		if(item instanceof Book) {
			Book book = (Book)item;
			int cost = 0;
			//if book price is more than 100 ruppe - give 5% discount
			if(book.getPrice()>100) {
				cost = book.getPrice()-5;
			}else {
				cost = book.getPrice();
			}
			System.out.println("Book "+book.getIsbnNumber() + " cost "+cost);
			
			return cost;
		}else if(item instanceof Fruit) {
			Fruit fruit = (Fruit)item;
			int cost = fruit.getPricePerKg()*fruit.getWeight();
			System.out.println(fruit.getName()+" cost :"+cost);
			return cost;
		}else {
			return 0;
		}
	}
	
}
