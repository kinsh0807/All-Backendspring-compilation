package com.masai.creational_pattern.proxy;

import java.util.ArrayList;
import java.util.List;

public class ProxyInternet implements Internet{

	private Internet internet = new RealInternet();
	private static List<String> bannedSites;
	
	static {
		bannedSites = new ArrayList<>();
		bannedSites.add("abc.com");
		bannedSites.add("xxx.com");
		bannedSites.add("xyz.com");
		bannedSites.add("cba.com");
	}
	
	@Override
	public void connect(String url) throws Exception{
	
		if(bannedSites.contains(url.toLowerCase())) {
			throw new Exception("Access Denied for url : "+url);
		}else {
			internet.connect(url);
		}
		
	}

	
}
