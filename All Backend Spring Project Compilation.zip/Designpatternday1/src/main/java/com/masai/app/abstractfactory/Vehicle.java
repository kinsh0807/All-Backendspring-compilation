package com.masai.app.abstractfactory;

public abstract class Vehicle {

    public abstract String getModel();
    public abstract String getRegNo();
    public abstract int getMakeYear();
    public abstract String getSpecialFeatures();

    public String toString() {
        return "Model="+getModel()+",RegNo="+getRegNo()+",MakeYear="+getMakeYear()+",SpecialFeatures="+getSpecialFeatures();

    }


}
