package com.masai.app.abstractfactory;

public class VehicleFactory {

    public static Vehicle getVehicle(String model, String RegNo, int MakeYear, String SpecialFeatures) {

        if("maruti".equalsIgnoreCase(type))
            return new Maruti(model,RegNo,MakeYear,SpecialFeatures);

        else if ("BMW".equalsIgnoreCase(type))
            return new BMW(model,RegNo,MakeYear,SpecialFeatures);

        else if ("Tata".equalsIgnoreCase(type))
            return new Tata(model,RegNo,MakeYear,SpecialFeatures);

        return null;


    }
}
