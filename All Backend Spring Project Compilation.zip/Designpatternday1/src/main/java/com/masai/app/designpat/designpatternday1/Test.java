package com.masai.app.designpat.designpatternday1;

public class Test {

    public static void main(String[] args) {
        //DatabaseConnector singleton = DatabaseConnector.getInstance();
        //System.out.println(singleton.hashCode());
        //DatabaseConnector singleton2 = DatabaseConnector.getInstance();
        //System.out.println(singleton2.hashCode());

        Lazyload_Singleton singleton = Lazyload_Singleton.getInstance();
        Lazyload_Singleton singleton2 = Lazyload_Singleton.getInstance();

        System.out.println(singleton.hashCode());
        System.out.println(singleton2.hashCode());
    }

}
