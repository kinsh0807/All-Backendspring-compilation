package com.masai.app.designpat.designpatternday1;


public class DatabaseConnector {

    private String URL;
    private String UserName;
    private String Password;

    public static final DatabaseConnector instance= new DatabaseConnector();

    private DatabaseConnector() {}

    public static DatabaseConnector getInstance() {
        return instance;
    }

    }

