package com.masai.app.designpat.designpatternday1;

import java.lang.reflect.Constructor;

public class Reflection_Sinchallenge {
    public static void main(String[] args) throws Exception {
        DatabaseConnector singleton1 = DatabaseConnector.getInstance();
        DatabaseConnector singleton2 = null;

        Constructor[] constructors = DatabaseConnector.class.getDeclaredConstructors();

        for(Constructor constructor : constructors) {
            constructor.setAccessible(true);
            singleton2 = (DatabaseConnector)constructor.newInstance();
            break;
        }
    }
}
