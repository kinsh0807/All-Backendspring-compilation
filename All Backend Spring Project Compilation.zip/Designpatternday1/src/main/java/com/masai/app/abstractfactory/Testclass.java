package com.masai.app.abstractfactory;

public class Testclass {

    public static void main(String[] args) {

        Vehicle vehicle = VehicleFactory.getVehicle("maruti","9AB34",2000,"Dashboard Design");

        System.out.println(vehicle);

        if(vehicle instanceof Maruti)
            System.out.println("Its a Maruti Vehicle");
        else if (vehicle instanceof BMW)
            System.out.println("Its a BMW Vehicle");
        else if (vehicle instanceof Tata)
            System.out.println("Its a Tata Vehicle");
    }
}