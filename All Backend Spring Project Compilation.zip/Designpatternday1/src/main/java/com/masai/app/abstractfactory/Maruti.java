package com.masai.app.abstractfactory;

public class Maruti extends Vehicle{

    private String model;
    private String RegNo;
    private int MakeYear;
    private String SpecialFeatures;

    public Maruti(String model, String RegNo, int makeYear, String specialFeatures) {
        super();
        this.model = model;
        this.RegNo = RegNo;
        this.MakeYear = makeYear;
        this.SpecialFeatures = specialFeatures;
    }

    @Override
    public String getModel() {
        return this.model;
    }

    @Override
    public String getRegNo() {
        return this.RegNo;
    }

    @Override
    public int getMakeYear() {
        return this.MakeYear;
    }

    @Override
    public String getSpecialFeatures() {
        return this.SpecialFeatures;
    }
}
