package com.masai.app.designpat.designpatternday1;

public class Lazyload_Singleton {

    private static Lazyload_Singleton instance;

    private Lazyload_Singleton () {}

    public static Lazyload_Singleton getInstance() {
        if(instance == null)
            instance = new Lazyload_Singleton();
        return instance;
    }
}
